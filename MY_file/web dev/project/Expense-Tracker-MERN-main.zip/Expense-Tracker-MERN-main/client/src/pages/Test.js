import React from 'react'
import DefaultLayout from '../components/DefaultLayout'

function Test() {
  return (
      <DefaultLayout><h1>This is test page</h1></DefaultLayout>
  )
}

export default Test